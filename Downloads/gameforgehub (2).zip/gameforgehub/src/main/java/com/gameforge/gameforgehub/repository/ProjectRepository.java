package com.gameforge.gameforgehub.repository;

public class ProjectRepository {

}
