package com.gameforge.gameforgehub.controller;

import com.gameforge.gameforgehub.service.AuthService;
import com.gameforge.gameforgehub.model.User;
import com.gameforge.gameforgehub.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthService authService;
    
    @Autowired
    private UserRepository userRepository; // Inyectamos esto para poder registrar rápido
    
  //  @GetMapping("/register")
    //public String register(@RequestParam String username, @RequestParam String password) {
        // 1. Verificamos si el usuario ya existe para evitar el error 500
      //  if (userRepository.findByUsername(username).isPresent()) {
        //    return "Error: El nombre de usuario '" + username + "' ya está en uso. Intenta con otro.";
      //  }

        // 2. Si no existe, procedemos a guardar
     //   User newUser = new User();
      //  newUser.setUsername(username);
      //  newUser.setPassword(password);
      //  userRepository.save(newUser);
        
    //    return "Usuario '" + username + "' creado con éxito. Ya puedes intentar el login.";
    // }      
                      
    
    
    
    // CAMBIO: Usamos GetMapping para probar en el navegador
    @GetMapping("/login") 
    public String login(@RequestParam String username, @RequestParam String password) {
        if (authService.login(username, password)) {
            return "¡Login exitoso! Bienvenido " + username;
        }
        return "Error: Usuario o contraseña incorrectos.";
    }

    // NUEVO: Método para crear un usuario de prueba
    @GetMapping("/register")
    public String register(@RequestParam String username, @RequestParam String password) {
        User newUser = new User();
       newUser.setUsername(username);
        newUser.setPassword(password);
        userRepository.save(newUser);
        return "Usuario '" + username + "' creado con éxito. Ya puedes intentar el login.";
    }
    
    
    
    @GetMapping("/logout")
    public String logout() {
        authService.logout();
        return "Has cerrado sesión correctamente.";
    }
}