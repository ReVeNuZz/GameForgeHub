package com.gameforge.gameforgehub.model;

public class Task {

}
